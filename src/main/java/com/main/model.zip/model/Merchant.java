package com.main.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import org.springframework.lang.NonNull;

@Entity
public class Merchant 
{
	@Id
	@SequenceGenerator(name="generator" ,sequenceName = "seqmid" , allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "generator")
	private long MId;

	
	@NonNull
	private String memail;
	
	@NonNull
	private String mpwd;
	
	private String mname;
	private int mage;
	private int mphno;
	
	@OneToOne
	@JoinColumn(name = "addressId")
	private Address address;
	private String mfirmname;
	private String mgstno;
	private LocalDateTime date;
	
	
	public long getMId() {
		return MId;
	}
	public void setMId(long mId) {
		MId = mId;
	}
	public String getmEmail() {
		return memail;
	}
	public void setmEmail(String mEmail) {
		this.memail = mEmail;
	}
	public String getmPwd() {
		return mpwd;
	}
	public void setmPwd(String mPwd) {
		this.mpwd = mPwd;
	}
	public String getmName() {
		return mname;
	}
	public void setmName(String mName) {
		this.mname = mName;
	}
	public int getmAge() {
		return mage;
	}
	public void setmAge(int mAge) {
		this.mage = mAge;
	}
	public int getmPhno() {
		return mphno;
	}
	public void setmPhno(int mPhno) {
		this.mphno = mPhno;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getmFirmname() {
		return mfirmname;
	}
	public void setmFirmname(String mFirmname) {
		this.mfirmname = mFirmname;
	}
	public String getmGstno() {
		return mgstno;
	}
	public void setmGstno(String mGstno) {
		this.mgstno = mGstno;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public Merchant(long mId, String memail, String mpwd, String mname, int mage, int mphno, Address address,
			String mfirmname, String mgstno, LocalDateTime date) {
		super();
		MId = mId;
		this.memail = memail;
		this.mpwd = mpwd;
		this.mname = mname;
		this.mage = mage;
		this.mphno = mphno;
		this.address = address;
		this.mfirmname = mfirmname;
		this.mgstno = mgstno;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Merchant [MId=" + MId + ", memail=" + memail + ", mpwd=" + mpwd + ", mname=" + mname + ", mage=" + mage
				+ ", mphno=" + mphno + ", address=" + address + ", mfirmname=" + mfirmname + ", mgstno=" + mgstno
				+ ", date=" + date + "]";
	}
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
