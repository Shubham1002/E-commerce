package com.main.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Cartitems 
{
	@Id
	@SequenceGenerator(name="generator" ,sequenceName = "seqcartitemid" , allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "generator")
	private long cartitemId;
	
	@ManyToOne
	@JoinColumn(name="cartId")
	private Cart cart;
	
	@ManyToOne
	@JoinColumn(name="proddescId")
	private Productdesc prod;
	
	private int Qty;
	
	private LocalDateTime date;
	

	public long getCartitemId() {
		return cartitemId;
	}

	public void setCartitemId(long cartitemId) {
		this.cartitemId = cartitemId;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Productdesc getProd() {
		return prod;
	}

	public void setProd(Productdesc prod) {
		this.prod = prod;
	}

	public int getQty() {
		return Qty;
	}

	public void setQty(int qty) {
		Qty = qty;
	}

	public Cartitems() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public Cartitems(long cartitemId, Cart cart, Productdesc prod, int qty, LocalDateTime date) {
		super();
		this.cartitemId = cartitemId;
		this.cart = cart;
		this.prod = prod;
		Qty = qty;
		this.date = date;
	}

	@Override
	public String toString() {
		return "Cartitems [cartitemId=" + cartitemId + ", cart=" + cart + ", prod=" + prod + ", Qty=" + Qty + ", date="
				+ date + "]";
	}
}
